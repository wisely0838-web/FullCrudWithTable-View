/*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
import { cats , sequelize } from "../models/Cat.js";
await sequelize.sync();
const Cat ={
  index: async (req, res) => {
    const data = await cats.findAll();
    res.render("cat", { data });
  },
  add: (req, res) => {
    res.render("add");
  },
  insert: async(req, res) => {
        const { Name, Breed, Age, Gender, Color, Weight } = req.body;
        await cats.create({Name, Breed, Age, Gender, Color, Weight});
        res.redirect("/cat");
  },
  get: async(req, res) =>{
    const data = await cats.findAll();
    res.json(data);
  },
  show: async(req, res) =>{
    const {id} = req.params;
    const data = await cats.findByPk(id);
    res.json(data);
  },
  edit: async (req, res) => {
    const { id } = req.params;
    const data = await cats.findByPk(id);
    res.render("edit", { data });
  },
  update: async (req, res) => {
    const {id} = req.params;
    const { Name, Breed, Age, Gender, Color, Weight } = req.body;
    await cats.update({ Name, Breed, Age, Gender, Color, Weight }, {where: {id}});
    res.redirect("/cat");
  },
  delete: async (req, res) => {
    const {id} = req.params;
    await cats.destroy({where: { id }});
    res.redirect("/cat");
  },  
  updates: async (req, res) => {
    const { id } = req.params;
    const { Name, Breed, Age, Gender, Color, Weight } = req.body;
    await cats.update({ Name, Breed, Age, Gender, Color, Weight }, { where: {id}});
    const data = await cats.findByPk(id);
    res.json({Message: "Cat updated successfully!",data});
  },
  deleted: async (req, res) => {
    const { id } = req.params;
    await cats.destroy({ where: { id } });
    res.json({Message: "Cat deleted successfully!"});
  },
};
export { Cat };
